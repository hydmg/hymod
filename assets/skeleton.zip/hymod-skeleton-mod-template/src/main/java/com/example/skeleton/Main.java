package <PACKAGE>;

public class Main {
    public Main() {
        System.out.println("Hello, Hytale!");
    }
}
